"""CLI entrypoints for local development and experiments."""

from __future__ import annotations

import asyncio
import signal
from itertools import cycle, islice
from pathlib import Path
from typing import Annotated, Any

import typer

from benchmark.analyzer import PerformanceAnalyzer
from benchmark.models import BenchmarkResult, BenchmarkRunRecord
from benchmark.reporting import (
    aggregate_run_records,
    export_benchmark_bundle,
    render_aggregate_table,
)
from client.factory import create_translator
from registry.consul import ConsulServiceRegistry
from server.grpc_server import GrpcDictionaryServer
from server.repository import DictionaryRepository
from server.socket_server import SocketDictionaryServer
from shared.config import ConsulSettings, ServiceSettings
from shared.models import ProtocolType

app = typer.Typer(help="Distributed lab command line tools.")


@app.command("run-socket-server")
def run_socket_server(
    host: Annotated[str, typer.Option(help="Socket server bind host.")] = "127.0.0.1",
    advertise_host: Annotated[
        str, typer.Option(help="Host registered in Consul.")
    ] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Socket server port.")] = 50051,
    service_name: Annotated[
        str, typer.Option(help="Logical service name for discovery.")
    ] = "remote-dictionary",
    db_path: Annotated[str, typer.Option(help="SQLite database path.")] = (
        "data/socket_dictionary.db"
    ),
    seed_path: Annotated[str, typer.Option(help="Dictionary seed JSON path.")] = (
        "data/dictionary_seed.json"
    ),
    consul_host: Annotated[str, typer.Option(help="Consul host.")] = "127.0.0.1",
    consul_port: Annotated[int, typer.Option(help="Consul HTTP API port.")] = 8500,
) -> None:
    """Run the socket dictionary server."""
    asyncio.run(
        _serve(
            protocol=ProtocolType.SOCKET_JSON,
            host=host,
            advertise_host=advertise_host,
            port=port,
            service_name=service_name,
            db_path=db_path,
            seed_path=seed_path,
            consul_host=consul_host,
            consul_port=consul_port,
        )
    )


@app.command("run-grpc-server")
def run_grpc_server(
    host: Annotated[str, typer.Option(help="gRPC server bind host.")] = "127.0.0.1",
    advertise_host: Annotated[
        str, typer.Option(help="Host registered in Consul.")
    ] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="gRPC server port.")] = 50052,
    service_name: Annotated[
        str, typer.Option(help="Logical service name for discovery.")
    ] = "remote-dictionary",
    db_path: Annotated[str, typer.Option(help="SQLite database path.")] = (
        "data/grpc_dictionary.db"
    ),
    seed_path: Annotated[str, typer.Option(help="Dictionary seed JSON path.")] = (
        "data/dictionary_seed.json"
    ),
    consul_host: Annotated[str, typer.Option(help="Consul host.")] = "127.0.0.1",
    consul_port: Annotated[int, typer.Option(help="Consul HTTP API port.")] = 8500,
) -> None:
    """Run the gRPC dictionary server."""
    asyncio.run(
        _serve(
            protocol=ProtocolType.GRPC,
            host=host,
            advertise_host=advertise_host,
            port=port,
            service_name=service_name,
            db_path=db_path,
            seed_path=seed_path,
            consul_host=consul_host,
            consul_port=consul_port,
        )
    )


@app.command("benchmark")
def benchmark(
    protocol: Annotated[
        ProtocolType,
        typer.Option(help="Benchmark target protocol."),
    ] = ProtocolType.SOCKET_JSON,
    service_name: Annotated[
        str,
        typer.Option(help="Logical service name registered in Consul."),
    ] = "remote-dictionary",
    queries: Annotated[
        str,
        typer.Option(help="Comma-separated query words used by the benchmark."),
    ] = "hello,world,distributed,system,grpc,socket",
    total_requests: Annotated[
        int,
        typer.Option(help="Total request count."),
    ] = 200,
    concurrency: Annotated[
        int,
        typer.Option(help="Concurrent worker count."),
    ] = 20,
    server_pid: Annotated[
        int | None,
        typer.Option(help="Optional target server process ID for resource sampling."),
    ] = None,
    warmup_requests: Annotated[
        int,
        typer.Option(help="Warmup requests before the measured run."),
    ] = 5,
    consul_host: Annotated[str, typer.Option(help="Consul host.")] = "127.0.0.1",
    consul_port: Annotated[int, typer.Option(help="Consul HTTP API port.")] = 8500,
) -> None:
    """Run a benchmark case and print a comparison table."""
    asyncio.run(
        _benchmark(
            protocol=protocol,
            service_name=service_name,
            queries=queries,
            total_requests=total_requests,
            concurrency=concurrency,
            server_pid=server_pid,
            warmup_requests=warmup_requests,
            consul_host=consul_host,
            consul_port=consul_port,
        )
    )


@app.command("benchmark-matrix")
def benchmark_matrix(
    service_name: Annotated[
        str,
        typer.Option(help="Logical service name registered in Consul."),
    ] = "remote-dictionary",
    queries: Annotated[
        str,
        typer.Option(help="Comma-separated query words used by the benchmark."),
    ] = "hello,world,distributed,system,grpc,socket",
    total_requests: Annotated[
        int,
        typer.Option(help="Total request count for each case."),
    ] = 2000,
    concurrencies: Annotated[
        str,
        typer.Option(help="Comma-separated concurrency levels."),
    ] = "10,50,100,200",
    runs: Annotated[
        int,
        typer.Option(help="Repeat count for each protocol/concurrency case."),
    ] = 2,
    warmup_requests: Annotated[
        int,
        typer.Option(help="Warmup requests before each measured run."),
    ] = 5,
    socket_server_pid: Annotated[
        int,
        typer.Option(help="Socket server PID used for resource sampling."),
    ] = 0,
    grpc_server_pid: Annotated[
        int,
        typer.Option(help="gRPC server PID used for resource sampling."),
    ] = 0,
    output_dir: Annotated[
        str,
        typer.Option(help="Directory used to store exported benchmark artifacts."),
    ] = "benchmark/results/report",
    consul_host: Annotated[str, typer.Option(help="Consul host.")] = "127.0.0.1",
    consul_port: Annotated[int, typer.Option(help="Consul HTTP API port.")] = 8500,
) -> None:
    """Run a multi-concurrency benchmark matrix for both protocols."""
    if socket_server_pid <= 0:
        raise typer.BadParameter("socket-server-pid must be a positive integer")
    if grpc_server_pid <= 0:
        raise typer.BadParameter("grpc-server-pid must be a positive integer")

    asyncio.run(
        _benchmark_matrix(
            service_name=service_name,
            queries=queries,
            total_requests=total_requests,
            concurrencies=concurrencies,
            runs=runs,
            warmup_requests=warmup_requests,
            socket_server_pid=socket_server_pid,
            grpc_server_pid=grpc_server_pid,
            output_dir=output_dir,
            consul_host=consul_host,
            consul_port=consul_port,
        )
    )


async def _serve(
    *,
    protocol: ProtocolType,
    host: str,
    advertise_host: str,
    port: int,
    service_name: str,
    db_path: str,
    seed_path: str,
    consul_host: str,
    consul_port: int,
) -> None:
    settings = ServiceSettings(
        service_name=service_name,
        protocol=protocol,
        bind_host=host,
        advertise_host=advertise_host,
        port=port,
        db_path=db_path,
        seed_path=seed_path,
    )
    registry = ConsulServiceRegistry(
        ConsulSettings(host=consul_host, port=consul_port)
    )
    repository = DictionaryRepository(settings.db_path, settings.seed_path)
    server: SocketDictionaryServer | GrpcDictionaryServer
    if protocol == ProtocolType.SOCKET_JSON:
        server = SocketDictionaryServer(settings, registry, repository)
    else:
        server = GrpcDictionaryServer(settings, registry, repository)

    stop_event = asyncio.Event()
    _install_signal_handlers(stop_event)
    await server.start()
    try:
        await stop_event.wait()
    finally:
        await server.stop()


async def _benchmark(
    *,
    protocol: ProtocolType,
    service_name: str,
    queries: str,
    total_requests: int,
    concurrency: int,
    server_pid: int | None,
    warmup_requests: int,
    consul_host: str,
    consul_port: int,
) -> None:
    result = await _run_benchmark_case(
        protocol=protocol,
        service_name=service_name,
        queries=queries,
        total_requests=total_requests,
        concurrency=concurrency,
        server_pid=server_pid,
        warmup_requests=warmup_requests,
        consul_host=consul_host,
        consul_port=consul_port,
    )
    typer.echo(PerformanceAnalyzer.render_table([result]))


async def _benchmark_matrix(
    *,
    service_name: str,
    queries: str,
    total_requests: int,
    concurrencies: str,
    runs: int,
    warmup_requests: int,
    socket_server_pid: int,
    grpc_server_pid: int,
    output_dir: str,
    consul_host: str,
    consul_port: int,
) -> None:
    raw_records: list[BenchmarkRunRecord] = []
    for protocol in (ProtocolType.SOCKET_JSON, ProtocolType.GRPC):
        server_pid = (
            socket_server_pid
            if protocol == ProtocolType.SOCKET_JSON
            else grpc_server_pid
        )
        for concurrency in _parse_concurrency_list(concurrencies):
            for run_number in range(1, runs + 1):
                result = await _run_benchmark_case(
                    protocol=protocol,
                    service_name=service_name,
                    queries=queries,
                    total_requests=total_requests,
                    concurrency=concurrency,
                    server_pid=server_pid,
                    warmup_requests=warmup_requests,
                    consul_host=consul_host,
                    consul_port=consul_port,
                )
                raw_records.append(
                    BenchmarkRunRecord.from_result(result, run_number=run_number)
                )

    aggregates = aggregate_run_records(raw_records)
    export_benchmark_bundle(
        Path(output_dir),
        raw_records=raw_records,
        aggregates=aggregates,
    )
    typer.echo(render_aggregate_table(aggregates))


async def _run_benchmark_case(
    *,
    protocol: ProtocolType,
    service_name: str,
    queries: str,
    total_requests: int,
    concurrency: int,
    server_pid: int | None,
    warmup_requests: int,
    consul_host: str,
    consul_port: int,
) -> BenchmarkResult:
    settings = ServiceSettings(
        service_name=service_name,
        protocol=protocol,
        benchmark_total_requests=total_requests,
        benchmark_concurrency=concurrency,
    )
    registry = ConsulServiceRegistry(
        ConsulSettings(host=consul_host, port=consul_port)
    )
    translator = create_translator(protocol, settings, registry)
    analyzer = PerformanceAnalyzer()
    prepared_queries = _build_queries(queries, total_requests)
    warmup_queries = _build_queries(queries, warmup_requests)
    provider_name = (
        "socket-json-provider"
        if protocol == ProtocolType.SOCKET_JSON
        else "grpc-provider"
    )

    try:
        await _warm_up_translator(translator, warmup_queries)
        return await analyzer.run_case(
            translator,
            protocol=protocol,
            queries=prepared_queries,
            concurrency=concurrency,
            provider_name=provider_name,
            server_pid=server_pid,
        )
    finally:
        await _maybe_close(translator)


def _build_queries(queries: str, total_requests: int) -> list[str]:
    words = [word.strip() for word in queries.split(",") if word.strip()]
    if not words:
        raise typer.BadParameter("queries must contain at least one word")
    return list(islice(cycle(words), total_requests))


def _parse_concurrency_list(value: str) -> list[int]:
    levels = [item.strip() for item in value.split(",") if item.strip()]
    if not levels:
        raise typer.BadParameter("concurrencies must contain at least one integer")

    parsed: list[int] = []
    for item in levels:
        try:
            parsed.append(int(item))
        except ValueError as error:
            raise typer.BadParameter(
                f"invalid concurrency value: {item}"
            ) from error
    return parsed


def _install_signal_handlers(stop_event: asyncio.Event) -> None:
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            signal.signal(sig, lambda *_: stop_event.set())


async def _maybe_close(translator: Any) -> None:
    close = getattr(translator, "close", None)
    if close is not None:
        await close()


async def _warm_up_translator(translator: Any, queries: list[str]) -> None:
    for word in queries:
        await translator.translate(word)
