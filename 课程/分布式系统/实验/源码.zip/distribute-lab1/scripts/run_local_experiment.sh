#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

CONDA_ENV_NAME="${CONDA_ENV_NAME:-dist-lab-py311}"
CONSUL_VERSION="${CONSUL_VERSION:-1.21.2}"
CONSUL_ZIP="consul_${CONSUL_VERSION}_linux_amd64.zip"
CONSUL_URL="https://releases.hashicorp.com/consul/${CONSUL_VERSION}/${CONSUL_ZIP}"
CONSUL_BIN="${CONSUL_BIN:-${ROOT_DIR}/.local/bin/consul}"
CONSUL_DATA_DIR="${CONSUL_DATA_DIR:-${ROOT_DIR}/.local/consul-data}"
OUTPUT_DIR="${OUTPUT_DIR:-benchmark/results/run_local}"
SERVICE_NAME="${SERVICE_NAME:-remote-dictionary}"
SOCKET_PORT="${SOCKET_PORT:-50051}"
GRPC_PORT="${GRPC_PORT:-50052}"
TOTAL_REQUESTS="${TOTAL_REQUESTS:-3000}"
CONCURRENCIES="${CONCURRENCIES:-10,50,100,200}"
RUNS="${RUNS:-2}"
WARMUP_REQUESTS="${WARMUP_REQUESTS:-5}"
SKIP_TESTS="${SKIP_TESTS:-0}"
QUERIES="${QUERIES:-hello,world,distributed,system,grpc,socket,network,performance,consistency,client,server,registry}"

CONSUL_PID=""
SOCKET_PID=""
GRPC_PID=""

cleanup() {
  local exit_code=$?
  set +e
  for pid in "${SOCKET_PID}" "${GRPC_PID}" "${CONSUL_PID}"; do
    if [[ -n "${pid}" ]] && kill -0 "${pid}" >/dev/null 2>&1; then
      kill -INT "${pid}" >/dev/null 2>&1 || true
      wait "${pid}" >/dev/null 2>&1 || true
    fi
  done
  exit "${exit_code}"
}

trap cleanup EXIT

activate_conda() {
  if ! command -v conda >/dev/null 2>&1; then
    echo "conda command not found"
    exit 1
  fi
  eval "$(conda shell.bash hook)"
  conda activate base
  conda activate "${CONDA_ENV_NAME}"
}

ensure_consul() {
  if [[ -x "${CONSUL_BIN}" ]]; then
    return
  fi

  mkdir -p "${ROOT_DIR}/.local/bin" "${ROOT_DIR}/.local/tmp"
  curl -L -o "${ROOT_DIR}/.local/tmp/${CONSUL_ZIP}" "${CONSUL_URL}"
  unzip -o "${ROOT_DIR}/.local/tmp/${CONSUL_ZIP}" -d "${ROOT_DIR}/.local/bin"
  chmod +x "${CONSUL_BIN}"
}

wait_for_url() {
  local url="$1"
  local retries="${2:-30}"
  local delay_seconds="${3:-1}"

  for ((i = 1; i <= retries; i++)); do
    if curl -fsS "${url}" >/dev/null 2>&1; then
      return
    fi
    sleep "${delay_seconds}"
  done

  echo "Timed out waiting for ${url}"
  exit 1
}

wait_for_registration() {
  for ((i = 1; i <= 30; i++)); do
    if python - <<'PY'
import json
import sys
from urllib.request import urlopen

with urlopen("http://127.0.0.1:8500/v1/health/service/remote-dictionary?passing=true", timeout=2) as response:
    payload = json.load(response)

protocols = {item["Service"]["Meta"].get("protocol") for item in payload}
if {"socket-json", "grpc"}.issubset(protocols):
    sys.exit(0)
sys.exit(1)
PY
    then
      return
    fi
    sleep 1
  done

  echo "Timed out waiting for service registration"
  exit 1
}

mkdir -p "${OUTPUT_DIR}/logs"

activate_conda
pip install -e '.[dev]'
ensure_consul

echo "Starting Consul..."
"${CONSUL_BIN}" agent \
  -dev \
  -client=127.0.0.1 \
  -bind=127.0.0.1 \
  -data-dir="${CONSUL_DATA_DIR}" \
  -node=dist-lab-dev \
  >"${OUTPUT_DIR}/logs/consul.log" 2>&1 &
CONSUL_PID=$!
wait_for_url "http://127.0.0.1:8500/v1/status/leader"

echo "Starting socket server..."
dist-lab run-socket-server \
  --host 127.0.0.1 \
  --advertise-host 127.0.0.1 \
  --port "${SOCKET_PORT}" \
  --service-name "${SERVICE_NAME}" \
  --db-path data/socket_dictionary.db \
  --seed-path data/dictionary_seed.json \
  --consul-host 127.0.0.1 \
  --consul-port 8500 \
  >"${OUTPUT_DIR}/logs/socket_server.log" 2>&1 &
SOCKET_PID=$!

echo "Starting gRPC server..."
dist-lab run-grpc-server \
  --host 127.0.0.1 \
  --advertise-host 127.0.0.1 \
  --port "${GRPC_PORT}" \
  --service-name "${SERVICE_NAME}" \
  --db-path data/grpc_dictionary.db \
  --seed-path data/dictionary_seed.json \
  --consul-host 127.0.0.1 \
  --consul-port 8500 \
  >"${OUTPUT_DIR}/logs/grpc_server.log" 2>&1 &
GRPC_PID=$!

wait_for_registration

if [[ "${SKIP_TESTS}" != "1" ]]; then
  echo "Running checks..."
  ruff check .
  mypy .
  pytest -q
fi

echo "Running benchmark matrix..."
dist-lab benchmark-matrix \
  --service-name "${SERVICE_NAME}" \
  --queries "${QUERIES}" \
  --total-requests "${TOTAL_REQUESTS}" \
  --concurrencies "${CONCURRENCIES}" \
  --runs "${RUNS}" \
  --warmup-requests "${WARMUP_REQUESTS}" \
  --socket-server-pid "${SOCKET_PID}" \
  --grpc-server-pid "${GRPC_PID}" \
  --output-dir "${OUTPUT_DIR}"

echo "Experiment finished."
echo "Results stored in ${OUTPUT_DIR}"
