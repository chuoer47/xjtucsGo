"""Base discovery-aware client translator."""

from __future__ import annotations

import abc
from datetime import timedelta
from typing import cast

from aiobreaker import CircuitBreaker
from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from client.discovery import DiscoveryCache, RoundRobinLoadBalancer
from registry.base import BaseServiceRegistry
from shared.base import BaseTranslator
from shared.config import ServiceSettings
from shared.models import ProtocolType, ServiceInstance, TranslationRequest


class DiscoveryTranslator(BaseTranslator, abc.ABC):
    """Common client logic for discovery, retry, and circuit breaking."""

    def __init__(
        self,
        settings: ServiceSettings,
        registry: BaseServiceRegistry,
        *,
        protocol: ProtocolType,
        service_name: str | None = None,
    ) -> None:
        self._settings = settings
        self._registry = registry
        self._protocol = protocol
        self._service_name = service_name or settings.service_name
        self._discovery_cache = DiscoveryCache(
            registry, ttl_seconds=settings.discovery_cache_seconds
        )
        self._load_balancer = RoundRobinLoadBalancer()
        self._breaker = CircuitBreaker(
            fail_max=settings.breaker_fail_max,
            timeout_duration=timedelta(seconds=settings.breaker_reset_timeout_seconds),
        )

    async def translate(self, word: str) -> str:
        """Translate a word via discovery-aware remote invocation."""
        request = TranslationRequest(word=word)

        retrying = AsyncRetrying(
            stop=stop_after_attempt(self._settings.retry_attempts),
            wait=wait_exponential(
                min=self._settings.retry_min_wait_seconds,
                max=self._settings.retry_max_wait_seconds,
            ),
            retry=retry_if_exception_type(self.retryable_exceptions()),
            reraise=True,
        )

        async for attempt in retrying:
            with attempt:
                instance = await self._pick_instance()
                try:
                    return cast(
                        str,
                        await self._breaker.call_async(
                            self._translate_once,
                            request,
                            instance,
                        ),
                    )
                except self.retryable_exceptions():
                    await self._discovery_cache.invalidate(
                        self._service_name, self._protocol
                    )
                    raise

        raise RuntimeError("retry loop exhausted unexpectedly")

    async def close(self) -> None:
        """Close downstream resources."""
        await self._registry.close()

    async def _pick_instance(self) -> ServiceInstance:
        instances = await self._discovery_cache.resolve(
            self._service_name, self._protocol
        )
        return await self._load_balancer.choose(instances)

    @abc.abstractmethod
    def retryable_exceptions(self) -> tuple[type[BaseException], ...]:
        """Return retryable exception classes."""

    @abc.abstractmethod
    async def _translate_once(
        self,
        request: TranslationRequest,
        instance: ServiceInstance,
    ) -> str:
        """Perform a single remote call."""
