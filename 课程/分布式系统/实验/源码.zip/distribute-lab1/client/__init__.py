"""Client adapters and discovery-aware transports."""
