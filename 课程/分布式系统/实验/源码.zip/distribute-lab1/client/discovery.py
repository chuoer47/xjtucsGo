"""Service discovery cache and load balancer."""

from __future__ import annotations

import asyncio
import time

from registry.base import BaseServiceRegistry
from shared.exceptions import DiscoveryError
from shared.models import ProtocolType, ServiceInstance


class RoundRobinLoadBalancer:
    """Simple round-robin load balancer."""

    def __init__(self) -> None:
        self._counters: dict[str, int] = {}
        self._lock = asyncio.Lock()

    async def choose(self, instances: list[ServiceInstance]) -> ServiceInstance:
        """Choose the next instance using round robin."""
        if not instances:
            raise DiscoveryError("no healthy service instances available")

        key = f"{instances[0].service_name}:{instances[0].protocol.value}"
        async with self._lock:
            # 专家视角：
            # 这里使用一个轻量全局锁保护轮询游标，
            # 保证并发下不会出现多个协程重复写回同一位置的竞态。
            # 更细粒度的分段锁可以进一步优化高并发，
            # 但复杂度更高；实验场景下优先保持实现清晰。
            current = self._counters.get(key, 0)
            self._counters[key] = (current + 1) % len(instances)
        return instances[current % len(instances)]


class DiscoveryCache:
    """Short-lived discovery cache to reduce registry pressure."""

    def __init__(
        self,
        registry: BaseServiceRegistry,
        *,
        ttl_seconds: float,
    ) -> None:
        self._registry = registry
        self._ttl_seconds = ttl_seconds
        self._cache: dict[str, tuple[float, list[ServiceInstance]]] = {}
        self._inflight: dict[str, asyncio.Task[list[ServiceInstance]]] = {}
        self._lock = asyncio.Lock()

    async def resolve(
        self, service_name: str, protocol: ProtocolType
    ) -> list[ServiceInstance]:
        """Resolve and cache healthy instances."""
        key = f"{service_name}:{protocol.value}"
        now = time.monotonic()

        async with self._lock:
            cached = self._cache.get(key)
            if cached is not None and cached[0] > now:
                return list(cached[1])
            inflight = self._inflight.get(key)
            if inflight is None:
                inflight = asyncio.create_task(
                    self._registry.discover(service_name, protocol)
                )
                self._inflight[key] = inflight

        try:
            instances = await inflight
        finally:
            async with self._lock:
                if self._inflight.get(key) is inflight:
                    self._inflight.pop(key, None)

        async with self._lock:
            # 专家视角：
            # 发现结果做短 TTL 缓存是典型的“一致性换性能”操作。
            # TTL 越短，客户端越能及时感知实例上下线；
            # TTL 越长，对注册中心的查询压力越小。
            # 这里额外引入“单飞”控制，避免缓存 miss 时并发协程一起压垮注册中心。
            # 它会轻微增加首个 miss 的等待时间，但能显著提升高并发稳定性。
            self._cache[key] = (time.monotonic() + self._ttl_seconds, list(instances))
            return list(instances)

    async def invalidate(self, service_name: str, protocol: ProtocolType) -> None:
        """Invalidate a cached discovery result."""
        key = f"{service_name}:{protocol.value}"
        async with self._lock:
            self._cache.pop(key, None)
