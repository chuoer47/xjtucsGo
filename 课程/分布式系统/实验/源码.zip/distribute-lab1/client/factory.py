"""Client factory helpers."""

from __future__ import annotations

from client.grpc_client import GrpcTranslatorClient
from client.socket_client import SocketTranslatorClient
from registry.base import BaseServiceRegistry
from shared.base import BaseTranslator
from shared.config import ServiceSettings
from shared.models import ProtocolType


def create_translator(
    protocol: ProtocolType,
    settings: ServiceSettings,
    registry: BaseServiceRegistry,
) -> BaseTranslator:
    """Create a translator client by protocol."""
    if protocol == ProtocolType.SOCKET_JSON:
        return SocketTranslatorClient(settings, registry)
    if protocol == ProtocolType.GRPC:
        return GrpcTranslatorClient(settings, registry)
    raise ValueError(f"unsupported protocol: {protocol}")
