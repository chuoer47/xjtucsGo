"""gRPC translator client."""

from __future__ import annotations

import asyncio
from typing import Any, cast

import grpc

from client.base import DiscoveryTranslator
from registry.base import BaseServiceRegistry
from shared import translator_pb2, translator_pb2_grpc
from shared.config import ServiceSettings
from shared.models import ProtocolType, ServiceInstance, TranslationRequest


class GrpcTranslatorClient(DiscoveryTranslator):
    """gRPC translator client."""

    def __init__(
        self,
        settings: ServiceSettings,
        registry: BaseServiceRegistry,
        *,
        service_name: str | None = None,
    ) -> None:
        super().__init__(
            settings,
            registry,
            protocol=ProtocolType.GRPC,
            service_name=service_name,
        )
        self._channels: dict[str, grpc.aio.Channel] = {}
        self._stubs: dict[str, Any] = {}

    def retryable_exceptions(self) -> tuple[type[BaseException], ...]:
        return (grpc.RpcError, asyncio.TimeoutError, OSError)

    async def close(self) -> None:
        for channel in self._channels.values():
            await channel.close()
        self._channels.clear()
        self._stubs.clear()
        await super().close()

    async def _translate_once(
        self,
        request: TranslationRequest,
        instance: ServiceInstance,
    ) -> str:
        stub = await self._get_stub(instance)
        response = await stub.Translate(
            translator_pb2.TranslateRequest(  # type: ignore[attr-defined]
                request_id=request.request_id,
                word=request.word,
            ),
            timeout=self._settings.request_timeout_seconds,
        )
        return cast(str, response.translation)

    async def _get_stub(
        self,
        instance: ServiceInstance,
    ) -> Any:
        endpoint = instance.endpoint
        if endpoint not in self._stubs:
            channel = grpc.aio.insecure_channel(
                endpoint,
                options=list(self._settings.grpc_channel_options),
            )
            await asyncio.wait_for(
                channel.channel_ready(),
                timeout=self._settings.socket_connect_timeout_seconds,
            )
            self._channels[endpoint] = channel
            self._stubs[endpoint] = translator_pb2_grpc.RemoteDictionaryStub(  # type: ignore[no-untyped-call]
                channel
            )
        return self._stubs[endpoint]
