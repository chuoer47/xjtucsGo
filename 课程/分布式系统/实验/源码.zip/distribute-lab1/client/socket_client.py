"""Socket translator client."""

from __future__ import annotations

import asyncio
import contextlib

from client.base import DiscoveryTranslator
from registry.base import BaseServiceRegistry
from shared.config import ServiceSettings
from shared.models import (
    ProtocolType,
    ServiceInstance,
    TranslationRequest,
    TranslationResponse,
)
from shared.socket_protocol import encode_frame, read_frame


class SocketTranslatorClient(DiscoveryTranslator):
    """Socket+JSON translator client."""

    def __init__(
        self,
        settings: ServiceSettings,
        registry: BaseServiceRegistry,
        *,
        service_name: str | None = None,
    ) -> None:
        super().__init__(
            settings,
            registry,
            protocol=ProtocolType.SOCKET_JSON,
            service_name=service_name,
        )

    def retryable_exceptions(self) -> tuple[type[BaseException], ...]:
        return (OSError, asyncio.TimeoutError)

    async def _translate_once(
        self,
        request: TranslationRequest,
        instance: ServiceInstance,
    ) -> str:
        reader: asyncio.StreamReader
        writer: asyncio.StreamWriter
        connection = asyncio.open_connection(instance.address, instance.port)
        reader, writer = await asyncio.wait_for(
            connection,
            timeout=self._settings.socket_connect_timeout_seconds,
        )

        try:
            writer.write(encode_frame(request))
            await writer.drain()
            payload = await asyncio.wait_for(
                read_frame(reader, max_body_bytes=self._settings.max_body_bytes),
                timeout=self._settings.request_timeout_seconds,
            )
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

        response = TranslationResponse.model_validate(payload)
        return response.translation
