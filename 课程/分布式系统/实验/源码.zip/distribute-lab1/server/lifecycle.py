"""Lifecycle helpers for registration, heartbeat, and graceful shutdown."""

from __future__ import annotations

import asyncio
import contextlib
import logging

from registry.base import BaseServiceRegistry
from shared.models import ServiceInstance

LOGGER = logging.getLogger(__name__)


class RegistryLifecycle:
    """Manage service registration and TTL heartbeats."""

    def __init__(
        self,
        registry: BaseServiceRegistry,
        instance: ServiceInstance,
        *,
        ttl_seconds: int,
        heartbeat_interval_seconds: float,
        deregister_after_seconds: int,
    ) -> None:
        self._registry = registry
        self._instance = instance
        self._ttl_seconds = ttl_seconds
        self._heartbeat_interval_seconds = heartbeat_interval_seconds
        self._deregister_after_seconds = deregister_after_seconds
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()

    async def start(self) -> None:
        """Register the service instance and start heartbeats."""
        await self._registry.register(
            self._instance,
            ttl_seconds=self._ttl_seconds,
            deregister_after_seconds=self._deregister_after_seconds,
        )
        await self._registry.heartbeat(self._instance.check_id)
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        """Stop heartbeats and deregister the service."""
        self._stop_event.set()
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None
        with contextlib.suppress(Exception):
            await self._registry.deregister(self._instance.instance_id)
        await self._registry.close()

    async def _heartbeat_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                await asyncio.sleep(self._heartbeat_interval_seconds)
                await self._registry.heartbeat(self._instance.check_id)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                LOGGER.warning("registry heartbeat failed: %s", error)
