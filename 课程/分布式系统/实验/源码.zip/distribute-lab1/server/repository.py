"""Async dictionary repository backed by SQLite."""

from __future__ import annotations

from pathlib import Path

import aiosqlite
import orjson


class DictionaryRepository:
    """Repository for dictionary lookups."""

    def __init__(self, db_path: str, seed_path: str) -> None:
        self._db_path = Path(db_path)
        self._seed_path = Path(seed_path)
        self._connection: aiosqlite.Connection | None = None

    async def start(self) -> None:
        """Open the database and initialize schema/data."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = await aiosqlite.connect(self._db_path.as_posix())
        await self._connection.execute("PRAGMA journal_mode=WAL;")
        await self._connection.execute("PRAGMA synchronous=NORMAL;")
        await self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS dictionary (
                word TEXT PRIMARY KEY,
                translation TEXT NOT NULL
            )
            """
        )
        await self._connection.commit()
        await self._seed_if_empty()

    async def close(self) -> None:
        """Close the SQLite connection."""
        if self._connection is not None:
            await self._connection.close()
            self._connection = None

    async def translate(self, word: str) -> str | None:
        """Return the translation if it exists."""
        connection = self._require_connection()
        async with connection.execute(
            "SELECT translation FROM dictionary WHERE word = ?",
            (word,),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return str(row[0])

    def _require_connection(self) -> aiosqlite.Connection:
        if self._connection is None:
            raise RuntimeError("repository has not been started")
        return self._connection

    async def _seed_if_empty(self) -> None:
        connection = self._require_connection()
        async with connection.execute("SELECT COUNT(*) FROM dictionary") as cursor:
            row = await cursor.fetchone()
        count = int(row[0]) if row else 0
        if count > 0:
            return

        payload = orjson.loads(self._seed_path.read_bytes())
        if not isinstance(payload, dict):
            raise ValueError("seed file must be a JSON object")

        # 专家视角：
        # 初始化阶段一次性批量导入词典，避免把冷启动放到首个请求路径上。
        # 这样能降低首包延迟波动，但代价是服务启动时间略长。
        records = [
            (str(word).strip().lower(), str(translation))
            for word, translation in payload.items()
        ]
        await connection.executemany(
            "INSERT OR REPLACE INTO dictionary(word, translation) VALUES (?, ?)",
            records,
        )
        await connection.commit()
