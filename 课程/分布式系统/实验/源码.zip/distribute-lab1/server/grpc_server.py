"""Async gRPC server implementation."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import grpc
from pydantic import ValidationError

from registry.base import BaseServiceRegistry
from server.lifecycle import RegistryLifecycle
from server.repository import DictionaryRepository
from server.service import DictionaryService
from shared import translator_pb2, translator_pb2_grpc
from shared.config import ServiceSettings
from shared.models import (
    HealthResponse,
    ProtocolType,
    ServiceInstance,
    TranslationRequest,
)

LOGGER = logging.getLogger(__name__)


class _GrpcDictionaryServicer(translator_pb2_grpc.RemoteDictionaryServicer):
    """gRPC servicer delegating to the shared business logic."""

    def __init__(self, service: DictionaryService) -> None:
        self._service = service

    async def Translate(  # noqa: N802
        self,
        request: Any,
        context: Any,
    ) -> Any:
        try:
            translated = await self._service.translate(
                TranslationRequest(
                    request_id=request.request_id,
                    word=request.word,
                )
            )
        except ValidationError as error:
            await context.abort(
                grpc.StatusCode.INVALID_ARGUMENT,
                error.errors()[0]["msg"],
            )
        return translator_pb2.TranslateResponse(  # type: ignore[attr-defined]
            request_id=translated.request_id,
            word=translated.word,
            translation=translated.translation,
            protocol=translated.protocol.value,
            provider=translated.provider,
            found=translated.found,
        )

    async def Health(  # noqa: N802
        self,
        request: Any,
        context: Any,
    ) -> Any:
        del request, context
        health = HealthResponse()
        return translator_pb2.HealthResponse(status=health.status)  # type: ignore[attr-defined]


class GrpcDictionaryServer:
    """Managed gRPC server with registry integration."""

    def __init__(
        self,
        settings: ServiceSettings,
        registry: BaseServiceRegistry,
        repository: DictionaryRepository,
    ) -> None:
        self._settings = settings
        self._registry = registry
        self._repository = repository
        self._service = DictionaryService(
            repository,
            protocol=ProtocolType.GRPC,
            provider_name="grpc-provider",
        )
        self._server: grpc.aio.Server | None = None
        self._lifecycle: RegistryLifecycle | None = None
        self._started = asyncio.Event()

    async def start(self) -> None:
        """Start the gRPC server and register it."""
        await self._repository.start()
        self._server = grpc.aio.server(
            options=list(self._settings.grpc_channel_options)
        )
        translator_pb2_grpc.add_RemoteDictionaryServicer_to_server(  # type: ignore[no-untyped-call]
            _GrpcDictionaryServicer(self._service),
            self._server,
        )
        listen_address = f"{self._settings.bind_host}:{self._settings.port}"
        bound_port = self._server.add_insecure_port(listen_address)
        if bound_port == 0:
            raise RuntimeError(f"failed to bind gRPC server to {listen_address}")
        await self._server.start()

        instance = self._build_instance(bound_port)
        self._lifecycle = RegistryLifecycle(
            self._registry,
            instance,
            ttl_seconds=self._settings.heartbeat_ttl_seconds,
            heartbeat_interval_seconds=self._settings.heartbeat_interval_seconds,
            deregister_after_seconds=self._settings.deregister_after_seconds,
        )
        await self._lifecycle.start()
        self._started.set()
        LOGGER.info("grpc server started on %s", listen_address)

    async def stop(self) -> None:
        """Stop the gRPC server gracefully."""
        if self._server is not None:
            await self._server.stop(grace=3)
            await self._server.wait_for_termination()
            self._server = None
        if self._lifecycle is not None:
            await self._lifecycle.stop()
            self._lifecycle = None
        await self._repository.close()

    async def wait_closed(self) -> None:
        """Wait for gRPC termination."""
        await self._started.wait()
        if self._server is not None:
            await self._server.wait_for_termination()

    def _build_instance(self, port: int) -> ServiceInstance:
        instance_id = (
            f"{self._settings.service_name}-"
            f"{ProtocolType.GRPC.value}-"
            f"{self._settings.advertise_host}-{port}"
        )
        return ServiceInstance(
            service_name=self._settings.service_name,
            instance_id=instance_id,
            address=self._settings.advertise_host,
            port=port,
            protocol=ProtocolType.GRPC,
            check_id=f"service:{instance_id}",
            meta={"transport": "http2"},
            tags=["grpc", "protobuf"],
        )
