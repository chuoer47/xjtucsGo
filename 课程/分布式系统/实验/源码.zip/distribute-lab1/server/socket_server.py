"""Async socket server with custom JSON framing."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from uuid import uuid4

from pydantic import ValidationError

from registry.base import BaseServiceRegistry
from server.lifecycle import RegistryLifecycle
from server.repository import DictionaryRepository
from server.service import DictionaryService
from shared.config import ServiceSettings
from shared.models import ProtocolType, ServiceInstance, TranslationRequest
from shared.socket_protocol import FrameBuffer, encode_frame

LOGGER = logging.getLogger(__name__)


class SocketDictionaryServer:
    """Custom TCP server for the dictionary service."""

    def __init__(
        self,
        settings: ServiceSettings,
        registry: BaseServiceRegistry,
        repository: DictionaryRepository,
    ) -> None:
        self._settings = settings
        self._registry = registry
        self._repository = repository
        self._service = DictionaryService(
            repository,
            protocol=ProtocolType.SOCKET_JSON,
            provider_name="socket-json-provider",
        )
        self._server: asyncio.Server | None = None
        self._lifecycle: RegistryLifecycle | None = None
        self._semaphore = asyncio.Semaphore(settings.max_concurrent_requests)

    async def start(self) -> None:
        """Start the TCP server and register it."""
        await self._repository.start()
        self._server = await asyncio.start_server(
            self._handle_client,
            host=self._settings.bind_host,
            port=self._settings.port,
        )
        instance = self._build_instance()
        self._lifecycle = RegistryLifecycle(
            self._registry,
            instance,
            ttl_seconds=self._settings.heartbeat_ttl_seconds,
            heartbeat_interval_seconds=self._settings.heartbeat_interval_seconds,
            deregister_after_seconds=self._settings.deregister_after_seconds,
        )
        await self._lifecycle.start()
        LOGGER.info(
            "socket server started on %s:%s", self._settings.bind_host, self.port
        )

    async def stop(self) -> None:
        """Stop the server gracefully."""
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        if self._lifecycle is not None:
            await self._lifecycle.stop()
            self._lifecycle = None
        await self._repository.close()

    async def wait_closed(self) -> None:
        """Wait until the TCP server finishes serving."""
        if self._server is not None:
            await self._server.serve_forever()

    @property
    def port(self) -> int:
        """Return the bound listening port."""
        if self._server is None or self._server.sockets is None:
            return self._settings.port
        socket = self._server.sockets[0]
        return int(socket.getsockname()[1])

    def _build_instance(self) -> ServiceInstance:
        instance_id = (
            f"{self._settings.service_name}-"
            f"{ProtocolType.SOCKET_JSON.value}-"
            f"{self._settings.advertise_host}-{self.port}"
        )
        return ServiceInstance(
            service_name=self._settings.service_name,
            instance_id=instance_id,
            address=self._settings.advertise_host,
            port=self.port,
            protocol=ProtocolType.SOCKET_JSON,
            check_id=f"service:{instance_id}",
            meta={"transport": "tcp"},
            tags=["socket", "json"],
        )

    async def _handle_client(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        buffer = FrameBuffer(max_body_bytes=self._settings.max_body_bytes)
        try:
            while not reader.at_eof():
                data = await reader.read(4096)
                if not data:
                    break
                for message in buffer.feed_data(data):
                    response = await self._process_message(message)
                    writer.write(encode_frame(response))
                    await writer.drain()
        except asyncio.IncompleteReadError:
            LOGGER.debug("client disconnected during frame read")
        except Exception as error:
            LOGGER.warning("socket client handler failed: %s", error)
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    async def _process_message(self, message: dict[str, object]) -> dict[str, object]:
        async with self._semaphore:
            try:
                request = TranslationRequest.model_validate(message)
                response = await self._service.translate(request)
                return response.model_dump(mode="json")
            except ValidationError as error:
                # 专家视角：
                # 对非法请求直接返回结构化错误，而不是让连接整体失败。
                # 这让单个坏包不会污染长连接上的后续请求，提升吞吐稳定性；
                # 代价是服务端必须承担额外的输入校验和错误编码成本。
                return {
                    "request_id": uuid4().hex,
                    "word": str(message.get("word", "")),
                    "translation": f"invalid request: {error.errors()[0]['msg']}",
                    "protocol": ProtocolType.SOCKET_JSON.value,
                    "provider": "socket-json-provider",
                    "found": False,
                }
