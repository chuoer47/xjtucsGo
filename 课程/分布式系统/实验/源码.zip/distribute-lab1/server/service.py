"""Shared dictionary business service."""

from __future__ import annotations

from server.repository import DictionaryRepository
from shared.models import ProtocolType, TranslationRequest, TranslationResponse


class DictionaryService:
    """Unified business logic used by both transport providers."""

    def __init__(
        self,
        repository: DictionaryRepository,
        *,
        protocol: ProtocolType,
        provider_name: str,
    ) -> None:
        self._repository = repository
        self._protocol = protocol
        self._provider_name = provider_name

    async def translate(self, request: TranslationRequest) -> TranslationResponse:
        """Translate a word and return a standardized response."""
        translation = await self._repository.translate(request.word)
        if translation is None:
            return TranslationResponse(
                request_id=request.request_id,
                word=request.word,
                translation="未找到对应译文",
                protocol=self._protocol,
                provider=self._provider_name,
                found=False,
            )

        return TranslationResponse(
            request_id=request.request_id,
            word=request.word,
            translation=translation,
            protocol=self._protocol,
            provider=self._provider_name,
            found=True,
        )
