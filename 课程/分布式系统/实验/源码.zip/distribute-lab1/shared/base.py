"""Shared translator abstractions."""

from __future__ import annotations

import abc


class BaseTranslator(abc.ABC):
    """翻译客户端统一抽象。

    尽管题目给出的接口描述是 ``translate(word: str) -> str``，
    这里仍采用 ``async`` 方法以适配全链路 ``asyncio`` 异步 IO。
    从业务契约上看，它依然表达“输入单词，输出译文”的统一语义。
    """

    @abc.abstractmethod
    async def translate(self, word: str) -> str:
        """Translate a word into its target language."""
