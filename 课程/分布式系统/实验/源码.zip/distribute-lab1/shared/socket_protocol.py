"""Socket framing helpers."""

from __future__ import annotations

import struct
from collections.abc import Mapping
from typing import Any

import orjson
from pydantic import BaseModel

from shared.exceptions import ProtocolError

HEADER_STRUCT = struct.Struct(">I")
HEADER_SIZE = HEADER_STRUCT.size


def _to_dict(payload: Mapping[str, Any] | BaseModel) -> dict[str, Any]:
    """Normalize supported payload types into a plain dict."""
    if isinstance(payload, BaseModel):
        return payload.model_dump(mode="json")
    return dict(payload)


def encode_json_body(payload: Mapping[str, Any] | BaseModel) -> bytes:
    """Encode a payload as compact JSON bytes."""
    return orjson.dumps(_to_dict(payload))


def encode_frame(payload: Mapping[str, Any] | BaseModel) -> bytes:
    """Encode a full socket frame with a 4-byte length header."""
    body = encode_json_body(payload)
    return HEADER_STRUCT.pack(len(body)) + body


def decode_json_body(body: bytes) -> dict[str, Any]:
    """Decode JSON bytes into a dictionary."""
    try:
        raw = orjson.loads(body)
    except orjson.JSONDecodeError as error:
        raise ProtocolError("invalid json body") from error
    if not isinstance(raw, dict):
        raise ProtocolError("json body must be an object")
    return raw


def json_payload_size(payload: Mapping[str, Any] | BaseModel) -> int:
    """Return unframed JSON payload size."""
    return len(encode_json_body(payload))


class FrameBuffer:
    """Incremental buffer for TCP sticky/partial packet handling."""

    def __init__(self, *, max_body_bytes: int = 65536) -> None:
        self._buffer = bytearray()
        self._max_body_bytes = max_body_bytes

    def feed_data(self, data: bytes) -> list[dict[str, Any]]:
        """Feed bytes and return all complete payloads parsed so far."""
        self._buffer.extend(data)
        messages: list[dict[str, Any]] = []

        while True:
            if len(self._buffer) < HEADER_SIZE:
                return messages

            body_length = HEADER_STRUCT.unpack_from(self._buffer, 0)[0]
            if body_length > self._max_body_bytes:
                raise ProtocolError(
                    f"frame body length {body_length} exceeds {self._max_body_bytes}"
                )

            frame_length = HEADER_SIZE + body_length
            if len(self._buffer) < frame_length:
                return messages

            # 专家视角：
            # 这里使用单个累积缓冲区，先确保“长度头 + 完整包体”都到齐才消费。
            # 这种做法比边读边猜协议边界更稳，牺牲的是在超大包场景下的内存占用。
            # 对课程实验而言，这个取舍更能体现“自定义协议需要自己处理一致性边界”。
            body = bytes(self._buffer[HEADER_SIZE:frame_length])
            del self._buffer[:frame_length]
            messages.append(decode_json_body(body))


async def read_frame(
    reader: Any,
    *,
    max_body_bytes: int = 65536,
) -> dict[str, Any]:
    """Read a single frame from an ``asyncio.StreamReader``."""
    header = await reader.readexactly(HEADER_SIZE)
    body_length = HEADER_STRUCT.unpack(header)[0]
    if body_length > max_body_bytes:
        raise ProtocolError(f"frame body length {body_length} exceeds {max_body_bytes}")
    body = await reader.readexactly(body_length)
    return decode_json_body(body)
