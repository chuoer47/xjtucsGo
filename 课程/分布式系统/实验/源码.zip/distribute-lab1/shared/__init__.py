"""Shared contracts, protocols, and generated assets."""
