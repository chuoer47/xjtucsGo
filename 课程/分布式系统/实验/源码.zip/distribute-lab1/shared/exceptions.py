"""Project-specific exceptions."""

from __future__ import annotations


class RegistryError(RuntimeError):
    """Raised when registry operations fail."""


class DiscoveryError(RuntimeError):
    """Raised when no healthy endpoints can be discovered."""


class ProtocolError(RuntimeError):
    """Raised when a protocol frame or payload is invalid."""


class TranslationNotFoundError(LookupError):
    """Raised when a translation entry does not exist."""
