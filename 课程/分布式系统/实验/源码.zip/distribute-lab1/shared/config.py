"""Configuration models for the distributed lab."""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from shared.models import ProtocolType


class ConsulSettings(BaseSettings):
    """Consul registry connection settings."""

    model_config = SettingsConfigDict(
        env_prefix="DIST_LAB_CONSUL_", env_file=".env", extra="ignore"
    )

    scheme: str = "http"
    host: str = "127.0.0.1"
    port: int = 8500
    token: str | None = None
    datacenter: str | None = None

    @property
    def base_url(self) -> str:
        """Return the Consul HTTP base URL."""
        return f"{self.scheme}://{self.host}:{self.port}"


class ServiceSettings(BaseSettings):
    """Server runtime settings."""

    model_config = SettingsConfigDict(
        env_prefix="DIST_LAB_", env_file=".env", extra="ignore"
    )

    service_name: str = "remote-dictionary"
    protocol: ProtocolType = ProtocolType.SOCKET_JSON
    bind_host: str = "127.0.0.1"
    advertise_host: str = "127.0.0.1"
    port: int = 50051
    db_path: str = "data/dictionary.db"
    seed_path: str = "data/dictionary_seed.json"
    heartbeat_ttl_seconds: int = 15
    heartbeat_interval_seconds: float = 5.0
    deregister_after_seconds: int = 60
    request_timeout_seconds: float = 3.0
    max_body_bytes: int = 65536
    max_concurrent_requests: int = 2048
    discovery_cache_seconds: float = 2.0
    breaker_fail_max: int = 5
    breaker_reset_timeout_seconds: int = 15
    retry_attempts: int = 3
    retry_min_wait_seconds: float = 0.05
    retry_max_wait_seconds: float = 0.5
    benchmark_duration_seconds: int = 10
    benchmark_concurrency: int = 50
    benchmark_total_requests: int = 1000
    grpc_max_workers: int | None = None
    socket_connect_timeout_seconds: float = 3.0
    grpc_channel_options: tuple[tuple[str, int], ...] = Field(
        default=(
            ("grpc.keepalive_time_ms", 30_000),
            ("grpc.keepalive_timeout_ms", 10_000),
            ("grpc.http2.max_pings_without_data", 0),
        )
    )
