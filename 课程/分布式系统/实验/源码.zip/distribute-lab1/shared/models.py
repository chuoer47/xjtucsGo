"""Shared data models."""

from __future__ import annotations

from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator


class ProtocolType(StrEnum):
    """Supported transport protocols."""

    SOCKET_JSON = "socket-json"
    GRPC = "grpc"


class TranslationRequest(BaseModel):
    """Business request payload."""

    request_id: str = Field(default_factory=lambda: uuid4().hex)
    word: str

    @field_validator("word")
    @classmethod
    def validate_word(cls, value: str) -> str:
        """Normalize and validate the incoming word."""
        normalized = value.strip().lower()
        if not normalized:
            raise ValueError("word must not be empty")
        return normalized


class TranslationResponse(BaseModel):
    """Business response payload."""

    request_id: str
    word: str
    translation: str
    protocol: ProtocolType
    provider: str
    found: bool = True


class HealthResponse(BaseModel):
    """Simple health response for both providers."""

    status: str = "SERVING"


class ServiceInstance(BaseModel):
    """Registry-discovered service instance."""

    service_name: str
    instance_id: str
    address: str
    port: int
    protocol: ProtocolType
    check_id: str
    tags: list[str] = Field(default_factory=list)
    meta: dict[str, str] = Field(default_factory=dict)

    @property
    def endpoint(self) -> str:
        """Return the host:port endpoint string."""
        return f"{self.address}:{self.port}"
