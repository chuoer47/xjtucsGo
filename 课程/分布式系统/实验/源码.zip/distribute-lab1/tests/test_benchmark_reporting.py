"""Tests for benchmark reporting helpers."""

from __future__ import annotations

from pathlib import Path

from benchmark.models import BenchmarkRunRecord
from benchmark.reporting import aggregate_run_records, export_benchmark_bundle
from shared.models import ProtocolType


def _record(
    protocol: ProtocolType,
    *,
    run_number: int,
    concurrency: int,
    qps: float,
    avg_latency_ms: float,
    p95_latency_ms: float,
    p99_latency_ms: float,
    cpu_peak_percent: float,
    rss_peak_mb: float,
) -> BenchmarkRunRecord:
    return BenchmarkRunRecord(
        protocol=protocol,
        run_number=run_number,
        total_requests=100,
        concurrency=concurrency,
        qps=qps,
        avg_latency_ms=avg_latency_ms,
        p95_latency_ms=p95_latency_ms,
        p99_latency_ms=p99_latency_ms,
        cpu_peak_percent=cpu_peak_percent,
        rss_peak_mb=rss_peak_mb,
        request_payload_bytes=18 if protocol == ProtocolType.GRPC else 41,
        response_payload_bytes=49 if protocol == ProtocolType.GRPC else 136,
    )


def test_aggregate_run_records_computes_means() -> None:
    records = [
        _record(
            ProtocolType.SOCKET_JSON,
            run_number=1,
            concurrency=50,
            qps=100.0,
            avg_latency_ms=10.0,
            p95_latency_ms=20.0,
            p99_latency_ms=30.0,
            cpu_peak_percent=50.0,
            rss_peak_mb=60.0,
        ),
        _record(
            ProtocolType.SOCKET_JSON,
            run_number=2,
            concurrency=50,
            qps=120.0,
            avg_latency_ms=14.0,
            p95_latency_ms=24.0,
            p99_latency_ms=34.0,
            cpu_peak_percent=70.0,
            rss_peak_mb=80.0,
        ),
    ]

    aggregates = aggregate_run_records(records)

    assert len(aggregates) == 1
    aggregate = aggregates[0]
    assert aggregate.avg_qps == 110.0
    assert aggregate.avg_latency_ms == 12.0
    assert aggregate.avg_p95_latency_ms == 22.0
    assert aggregate.avg_p99_latency_ms == 32.0
    assert aggregate.avg_cpu_peak_percent == 60.0
    assert aggregate.avg_rss_peak_mb == 70.0


def test_export_benchmark_bundle_writes_expected_files(tmp_path: Path) -> None:
    records = [
        _record(
            ProtocolType.SOCKET_JSON,
            run_number=1,
            concurrency=10,
            qps=100.0,
            avg_latency_ms=10.0,
            p95_latency_ms=20.0,
            p99_latency_ms=30.0,
            cpu_peak_percent=50.0,
            rss_peak_mb=60.0,
        ),
        _record(
            ProtocolType.GRPC,
            run_number=1,
            concurrency=10,
            qps=110.0,
            avg_latency_ms=11.0,
            p95_latency_ms=21.0,
            p99_latency_ms=31.0,
            cpu_peak_percent=70.0,
            rss_peak_mb=80.0,
        ),
    ]
    aggregates = aggregate_run_records(records)

    export_benchmark_bundle(tmp_path, raw_records=records, aggregates=aggregates)

    expected_files = [
        "raw_results.json",
        "raw_results.csv",
        "raw_results.md",
        "aggregate_results.json",
        "aggregate_results.csv",
        "aggregate_results.md",
        "qps.svg",
        "p95_latency.svg",
        "p99_latency.svg",
        "cpu_peak.svg",
        "rss_peak.svg",
        "payload_size.svg",
    ]
    for filename in expected_files:
        assert (tmp_path / filename).exists()
