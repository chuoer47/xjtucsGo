"""Common pytest fixtures."""

from __future__ import annotations

import socket
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

from shared.config import ServiceSettings
from shared.models import ProtocolType

SettingsFactory = Callable[..., ServiceSettings]


def find_free_port() -> int:
    """Find an available localhost TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return int(sock.getsockname()[1])


@pytest.fixture()
def seed_path() -> Path:
    """Return the seed dictionary path."""
    return Path(__file__).resolve().parents[1] / "data" / "dictionary_seed.json"


@pytest.fixture()
def settings_factory(seed_path: Path) -> SettingsFactory:
    """Build service settings for tests."""

    def _factory(
        tmp_path: Path,
        protocol: ProtocolType,
        **overrides: object,
    ) -> ServiceSettings:
        port_value = overrides.pop("port", 0)
        db_name_value = overrides.pop("db_name", f"{protocol.value}.db")
        if not isinstance(port_value, int):
            raise TypeError("port override must be an int")
        if not isinstance(db_name_value, str):
            raise TypeError("db_name override must be a str")

        defaults: dict[str, Any] = {
            "service_name": "test-dictionary",
            "protocol": protocol,
            "bind_host": "127.0.0.1",
            "advertise_host": "127.0.0.1",
            "port": port_value,
            "db_path": (tmp_path / db_name_value).as_posix(),
            "seed_path": seed_path.as_posix(),
            "heartbeat_ttl_seconds": 3,
            "heartbeat_interval_seconds": 0.5,
            "deregister_after_seconds": 10,
            "request_timeout_seconds": 1.0,
            "socket_connect_timeout_seconds": 1.0,
            "retry_attempts": 3,
            "retry_min_wait_seconds": 0.01,
            "retry_max_wait_seconds": 0.05,
            "discovery_cache_seconds": 0.1,
            "breaker_fail_max": 3,
            "breaker_reset_timeout_seconds": 30,
        }
        defaults.update(overrides)
        return ServiceSettings.model_validate(defaults)

    return _factory
