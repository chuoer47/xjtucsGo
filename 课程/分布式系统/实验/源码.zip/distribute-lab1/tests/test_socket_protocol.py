"""Tests for custom socket framing."""

from __future__ import annotations

import pytest

from shared.exceptions import ProtocolError
from shared.socket_protocol import FrameBuffer, encode_frame


def test_frame_buffer_handles_partial_packet() -> None:
    buffer = FrameBuffer()
    frame = encode_frame({"word": "hello"})

    assert buffer.feed_data(frame[:3]) == []
    assert buffer.feed_data(frame[3:]) == [{"word": "hello"}]


def test_frame_buffer_handles_sticky_packets() -> None:
    buffer = FrameBuffer()
    frames = encode_frame({"word": "hello"}) + encode_frame({"word": "world"})

    messages = buffer.feed_data(frames)

    assert messages == [{"word": "hello"}, {"word": "world"}]


def test_frame_buffer_rejects_oversized_packet() -> None:
    buffer = FrameBuffer(max_body_bytes=2)

    with pytest.raises(ProtocolError):
        buffer.feed_data(encode_frame({"word": "hello"}))
