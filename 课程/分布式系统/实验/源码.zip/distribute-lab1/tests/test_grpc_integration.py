"""End-to-end tests for the gRPC provider."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import pytest

from client.grpc_client import GrpcTranslatorClient
from registry.in_memory import InMemoryServiceRegistry
from server.grpc_server import GrpcDictionaryServer
from server.repository import DictionaryRepository
from shared.config import ServiceSettings
from shared.models import ProtocolType

SettingsFactory = Callable[..., ServiceSettings]


@pytest.mark.asyncio()
async def test_grpc_server_client_integration(
    tmp_path: Path,
    seed_path: Path,
    settings_factory: SettingsFactory,
) -> None:
    settings = settings_factory(tmp_path, ProtocolType.GRPC)
    registry = InMemoryServiceRegistry()
    repository = DictionaryRepository(settings.db_path, seed_path.as_posix())
    server = GrpcDictionaryServer(settings, registry, repository)
    client = GrpcTranslatorClient(settings, registry)

    await server.start()
    try:
        assert await client.translate("world") == "世界"
        assert await client.translate("unknown-word") == "未找到对应译文"
    finally:
        await client.close()
        await server.stop()
