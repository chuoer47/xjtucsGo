"""Tests for registry implementations."""

from __future__ import annotations

import asyncio

import pytest
from aiohttp import web

from registry.consul import ConsulServiceRegistry
from registry.in_memory import InMemoryServiceRegistry
from shared.config import ConsulSettings
from shared.models import ProtocolType, ServiceInstance


def _build_instance() -> ServiceInstance:
    return ServiceInstance(
        service_name="test-dictionary",
        instance_id="test-dictionary-socket-json-127.0.0.1-5000",
        address="127.0.0.1",
        port=5000,
        protocol=ProtocolType.SOCKET_JSON,
        check_id="service:test-dictionary-socket-json-127.0.0.1-5000",
        tags=["socket", "json"],
        meta={"transport": "tcp"},
    )


@pytest.mark.asyncio()
async def test_in_memory_registry_prunes_expired_instance() -> None:
    registry = InMemoryServiceRegistry()
    instance = _build_instance()

    await registry.register(instance, ttl_seconds=1, deregister_after_seconds=5)
    assert len(await registry.discover("test-dictionary")) == 1

    await asyncio.sleep(1.1)
    assert await registry.discover("test-dictionary") == []


@pytest.mark.asyncio()
async def test_consul_registry_register_discover_and_deregister() -> None:
    state: dict[str, object] = {
        "service_payload": None,
        "heartbeat_check_id": None,
        "deregistered": None,
    }

    async def register_handler(request: web.Request) -> web.Response:
        state["service_payload"] = await request.json()
        return web.Response(status=200)

    async def check_pass_handler(request: web.Request) -> web.Response:
        state["heartbeat_check_id"] = request.match_info["check_id"]
        return web.Response(status=200)

    async def deregister_handler(request: web.Request) -> web.Response:
        state["deregistered"] = request.match_info["instance_id"]
        return web.Response(status=200)

    async def discover_handler(request: web.Request) -> web.Response:
        del request
        payload = state["service_payload"]
        if not isinstance(payload, dict):
            return web.json_response([])
        return web.json_response(
            [
                {
                    "Service": {
                        "ID": payload["ID"],
                        "Service": payload["Name"],
                        "Address": payload["Address"],
                        "Port": payload["Port"],
                        "Tags": payload["Tags"],
                        "Meta": payload["Meta"],
                    }
                }
            ]
        )

    app = web.Application()
    app.router.add_put("/v1/agent/service/register", register_handler)
    app.router.add_put("/v1/agent/check/pass/{check_id}", check_pass_handler)
    app.router.add_put(
        "/v1/agent/service/deregister/{instance_id}",
        deregister_handler,
    )
    app.router.add_get("/v1/health/service/{service_name}", discover_handler)

    port = _find_free_port()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()

    registry = ConsulServiceRegistry(ConsulSettings(host="127.0.0.1", port=port))
    instance = _build_instance()

    try:
        await registry.register(instance, ttl_seconds=5, deregister_after_seconds=20)
        await registry.heartbeat(instance.check_id)
        discovered = await registry.discover(
            "test-dictionary",
            ProtocolType.SOCKET_JSON,
        )
        await registry.deregister(instance.instance_id)
    finally:
        await registry.close()
        await runner.cleanup()

    assert state["service_payload"] is not None
    assert state["heartbeat_check_id"] == instance.check_id
    assert state["deregistered"] == instance.instance_id
    assert [item.endpoint for item in discovered] == ["127.0.0.1:5000"]


def _find_free_port() -> int:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])
