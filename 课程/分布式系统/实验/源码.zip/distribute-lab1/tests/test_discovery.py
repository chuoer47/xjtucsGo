"""Tests for discovery, round robin, retry, and circuit breaker."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
from aiobreaker import CircuitBreakerError

from client.base import DiscoveryTranslator
from client.discovery import DiscoveryCache, RoundRobinLoadBalancer
from registry.in_memory import InMemoryServiceRegistry
from shared.config import ServiceSettings
from shared.models import ProtocolType, ServiceInstance, TranslationRequest

SettingsFactory = Callable[..., ServiceSettings]


def _instance(instance_id: str, port: int) -> ServiceInstance:
    return ServiceInstance(
        service_name="test-dictionary",
        instance_id=instance_id,
        address="127.0.0.1",
        port=port,
        protocol=ProtocolType.SOCKET_JSON,
        check_id=f"service:{instance_id}",
        tags=[],
        meta={},
    )


class _FlakyTranslator(DiscoveryTranslator):
    def __init__(
        self,
        settings: ServiceSettings,
        registry: InMemoryServiceRegistry,
        *,
        failures_before_success: int,
        always_fail: bool = False,
    ) -> None:
        super().__init__(
            settings,
            registry,
            protocol=ProtocolType.SOCKET_JSON,
            service_name="test-dictionary",
        )
        self.calls = 0
        self._failures_before_success = failures_before_success
        self._always_fail = always_fail

    def retryable_exceptions(self) -> tuple[type[BaseException], ...]:
        return (OSError,)

    async def _translate_once(
        self,
        request: TranslationRequest,
        instance: ServiceInstance,
    ) -> str:
        del request, instance
        self.calls += 1
        if self._always_fail or self.calls <= self._failures_before_success:
            raise OSError("transient failure")
        return "ok"


class _CountingRegistry(InMemoryServiceRegistry):
    def __init__(self) -> None:
        super().__init__()
        self.discover_calls = 0

    async def discover(
        self, service_name: str, protocol: ProtocolType | None = None
    ) -> list[ServiceInstance]:
        self.discover_calls += 1
        await asyncio_sleep(0.05)
        return await super().discover(service_name, protocol)


@pytest.mark.asyncio()
async def test_round_robin_load_balancer_rotates_instances() -> None:
    balancer = RoundRobinLoadBalancer()
    instances = [
        _instance("instance-a", 5001),
        _instance("instance-b", 5002),
        _instance("instance-c", 5003),
    ]

    chosen = [await balancer.choose(instances) for _ in range(4)]

    assert [item.instance_id for item in chosen] == [
        "instance-a",
        "instance-b",
        "instance-c",
        "instance-a",
    ]


@pytest.mark.asyncio()
async def test_discovery_translator_retries_until_success(
    tmp_path: Path,
    settings_factory: SettingsFactory,
) -> None:
    registry = InMemoryServiceRegistry()
    await registry.register(
        _instance("instance-a", 5001),
        ttl_seconds=10,
        deregister_after_seconds=20,
    )
    settings = settings_factory(
        tmp_path,
        ProtocolType.SOCKET_JSON,
        retry_attempts=3,
        breaker_fail_max=10,
    )
    translator = _FlakyTranslator(
        settings,
        registry,
        failures_before_success=2,
    )

    result = await translator.translate("hello")

    assert result == "ok"
    assert translator.calls == 3


@pytest.mark.asyncio()
async def test_discovery_cache_collapses_concurrent_registry_queries() -> None:
    registry = _CountingRegistry()
    await registry.register(
        _instance("instance-a", 5001),
        ttl_seconds=10,
        deregister_after_seconds=20,
    )
    cache = DiscoveryCache(registry, ttl_seconds=0.2)

    results = await asyncio_gather(
        *(
            cache.resolve("test-dictionary", ProtocolType.SOCKET_JSON)
            for _ in range(20)
        )
    )

    assert registry.discover_calls == 1
    assert len(results) == 20
    assert all(len(items) == 1 for items in results)


@pytest.mark.asyncio()
async def test_discovery_translator_opens_circuit_breaker(
    tmp_path: Path,
    settings_factory: SettingsFactory,
) -> None:
    registry = InMemoryServiceRegistry()
    await registry.register(
        _instance("instance-a", 5001),
        ttl_seconds=10,
        deregister_after_seconds=20,
    )
    settings = settings_factory(
        tmp_path,
        ProtocolType.SOCKET_JSON,
        retry_attempts=1,
        breaker_fail_max=2,
        breaker_reset_timeout_seconds=60,
    )
    translator = _FlakyTranslator(
        settings,
        registry,
        failures_before_success=0,
        always_fail=True,
    )

    with pytest.raises(OSError):
        await translator.translate("hello")
    with pytest.raises(CircuitBreakerError):
        await translator.translate("hello")
    with pytest.raises(CircuitBreakerError):
        await translator.translate("hello")

    assert str(translator._breaker.current_state) == "CircuitBreakerState.OPEN"


async def asyncio_sleep(seconds: float) -> None:
    await asyncio.sleep(seconds)


async def asyncio_gather(*aws: Any) -> list[Any]:
    return await asyncio.gather(*aws)
