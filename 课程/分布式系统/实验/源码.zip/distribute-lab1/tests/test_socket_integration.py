"""End-to-end tests for the socket provider."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import pytest

from client.socket_client import SocketTranslatorClient
from registry.in_memory import InMemoryServiceRegistry
from server.repository import DictionaryRepository
from server.socket_server import SocketDictionaryServer
from shared.config import ServiceSettings
from shared.models import ProtocolType

SettingsFactory = Callable[..., ServiceSettings]


@pytest.mark.asyncio()
async def test_socket_server_client_integration(
    tmp_path: Path,
    seed_path: Path,
    settings_factory: SettingsFactory,
) -> None:
    settings = settings_factory(tmp_path, ProtocolType.SOCKET_JSON)
    registry = InMemoryServiceRegistry()
    repository = DictionaryRepository(settings.db_path, seed_path.as_posix())
    server = SocketDictionaryServer(settings, registry, repository)
    client = SocketTranslatorClient(settings, registry)

    await server.start()
    try:
        assert await client.translate("hello") == "你好"
        assert await client.translate("unknown-word") == "未找到对应译文"
    finally:
        await client.close()
        await server.stop()
