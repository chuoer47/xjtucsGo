"""Tests for the async dictionary repository."""

from __future__ import annotations

from pathlib import Path

import pytest

from server.repository import DictionaryRepository


@pytest.mark.asyncio()
async def test_repository_seeds_and_translates(tmp_path: Path, seed_path: Path) -> None:
    repository = DictionaryRepository(
        db_path=(tmp_path / "dictionary.db").as_posix(),
        seed_path=seed_path.as_posix(),
    )

    await repository.start()
    try:
        assert await repository.translate("hello") == "你好"
        assert await repository.translate("missing") is None
    finally:
        await repository.close()
