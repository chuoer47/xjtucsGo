"""Tests for benchmark analysis."""

from __future__ import annotations

import asyncio

import pytest

from benchmark.analyzer import PerformanceAnalyzer
from benchmark.models import BenchmarkResult
from shared.base import BaseTranslator
from shared.models import ProtocolType


class _FakeTranslator(BaseTranslator):
    async def translate(self, word: str) -> str:
        await asyncio.sleep(0.001)
        return f"译文:{word}"


@pytest.mark.asyncio()
async def test_performance_analyzer_collects_metrics() -> None:
    analyzer = PerformanceAnalyzer()
    translator = _FakeTranslator()

    result = await analyzer.run_case(
        translator,
        protocol=ProtocolType.SOCKET_JSON,
        queries=["hello", "world", "system", "grpc"],
        concurrency=2,
        provider_name="socket-json-provider",
    )

    assert result.protocol == ProtocolType.SOCKET_JSON
    assert result.total_requests == 4
    assert result.qps > 0
    assert result.avg_latency_ms > 0
    assert result.p95_latency_ms >= result.avg_latency_ms
    assert result.request_payload_bytes > 0
    assert result.response_payload_bytes > 0


def test_render_table_contains_expected_headers() -> None:
    analyzer = PerformanceAnalyzer()
    table = analyzer.render_table(
        [
            BenchmarkResult(
                protocol=ProtocolType.GRPC,
                total_requests=10,
                concurrency=2,
                qps=100.0,
                avg_latency_ms=1.0,
                p95_latency_ms=2.0,
                p99_latency_ms=3.0,
                cpu_peak_percent=10.0,
                rss_peak_mb=20.0,
                request_payload_bytes=16,
                response_payload_bytes=24,
            )
        ]
    )

    assert "Protocol" in table
