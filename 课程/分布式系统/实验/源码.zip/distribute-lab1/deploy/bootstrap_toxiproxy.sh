#!/usr/bin/env bash
set -euo pipefail

TOXIPROXY_URL="${TOXIPROXY_URL:-http://127.0.0.1:8474}"
SOCKET_UPSTREAM="${SOCKET_UPSTREAM:-host.docker.internal:50051}"
GRPC_UPSTREAM="${GRPC_UPSTREAM:-host.docker.internal:50052}"
LATENCY_MS="${LATENCY_MS:-80}"
JITTER_MS="${JITTER_MS:-20}"

create_proxy() {
  local name="$1"
  local listen="$2"
  local upstream="$3"

  curl -sS -X POST "${TOXIPROXY_URL}/proxies" \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"${name}\",\"listen\":\"0.0.0.0:${listen}\",\"upstream\":\"${upstream}\"}" \
    >/dev/null || true
}

create_toxic() {
  local proxy_name="$1"
  local toxic_name="$2"

  curl -sS -X POST "${TOXIPROXY_URL}/proxies/${proxy_name}/toxics" \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"${toxic_name}\",\"type\":\"latency\",\"stream\":\"downstream\",\"attributes\":{\"latency\":${LATENCY_MS},\"jitter\":${JITTER_MS}}}" \
    >/dev/null || true
}

create_proxy "socket-dictionary" "18661" "${SOCKET_UPSTREAM}"
create_proxy "grpc-dictionary" "18662" "${GRPC_UPSTREAM}"
create_toxic "socket-dictionary" "socket-latency"
create_toxic "grpc-dictionary" "grpc-latency"

echo "Toxiproxy initialized."
echo "Socket proxy: 127.0.0.1:18661 -> ${SOCKET_UPSTREAM}"
echo "gRPC proxy:   127.0.0.1:18662 -> ${GRPC_UPSTREAM}"
