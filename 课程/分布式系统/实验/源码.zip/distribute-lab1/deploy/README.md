# Deploy Guide

启动基础设施：

```bash
docker compose -f deploy/docker-compose.yml up -d
```

初始化网络抖动代理：

```bash
bash deploy/bootstrap_toxiproxy.sh
```

默认情况下：

- `Consul UI`: `http://127.0.0.1:8500`
- `Toxiproxy API`: `http://127.0.0.1:8474`
- `Socket Proxy`: `127.0.0.1:18661`
- `gRPC Proxy`: `127.0.0.1:18662`

可通过环境变量调整抖动参数：

```bash
LATENCY_MS=120 JITTER_MS=30 bash deploy/bootstrap_toxiproxy.sh
```
