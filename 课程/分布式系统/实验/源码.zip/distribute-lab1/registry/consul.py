"""Consul-backed service registry."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from urllib.parse import quote

import aiohttp

from registry.base import BaseServiceRegistry
from shared.config import ConsulSettings
from shared.exceptions import RegistryError
from shared.models import ProtocolType, ServiceInstance


class ConsulServiceRegistry(BaseServiceRegistry):
    """Consul HTTP API wrapper."""

    def __init__(
        self,
        settings: ConsulSettings,
        *,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self._settings = settings
        self._session = session
        self._owns_session = session is None

    async def close(self) -> None:
        """Close the internal client session if owned."""
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    async def register(
        self,
        instance: ServiceInstance,
        *,
        ttl_seconds: int,
        deregister_after_seconds: int,
    ) -> None:
        """Register a service instance with a TTL health check."""
        payload = {
            "ID": instance.instance_id,
            "Name": instance.service_name,
            "Address": instance.address,
            "Port": instance.port,
            "Tags": instance.tags,
            "Meta": {
                "protocol": instance.protocol.value,
                **instance.meta,
            },
            "Check": {
                "CheckID": instance.check_id,
                "Name": f"{instance.service_name}-{instance.protocol.value}-ttl",
                "TTL": f"{ttl_seconds}s",
                "DeregisterCriticalServiceAfter": f"{deregister_after_seconds}s",
                "Status": "passing",
            },
        }
        await self._request("PUT", "/v1/agent/service/register", json=payload)

    async def heartbeat(self, check_id: str) -> None:
        """Mark the TTL check as passing."""
        quoted = quote(check_id, safe="")
        await self._request("PUT", f"/v1/agent/check/pass/{quoted}")

    async def deregister(self, instance_id: str) -> None:
        """Deregister a service instance."""
        quoted = quote(instance_id, safe="")
        await self._request("PUT", f"/v1/agent/service/deregister/{quoted}")

    async def discover(
        self, service_name: str, protocol: ProtocolType | None = None
    ) -> list[ServiceInstance]:
        """Discover healthy service instances."""
        response = await self._request(
            "GET",
            f"/v1/health/service/{quote(service_name, safe='')}",
            params={"passing": "true"},
        )
        items = response if isinstance(response, list) else []
        instances: list[ServiceInstance] = []

        for item in items:
            if not isinstance(item, Mapping):
                continue
            service = item.get("Service", {})
            if not isinstance(service, Mapping):
                continue
            meta = service.get("Meta", {})
            if not isinstance(meta, Mapping):
                meta = {}

            raw_protocol = meta.get("protocol")
            if not isinstance(raw_protocol, str):
                continue
            instance_protocol = ProtocolType(raw_protocol)
            if protocol is not None and instance_protocol != protocol:
                continue

            port = service.get("Port", 0)
            if not isinstance(port, int):
                continue

            instances.append(
                ServiceInstance(
                    service_name=str(service.get("Service", service_name)),
                    instance_id=str(service.get("ID", "")),
                    address=str(service.get("Address", "")),
                    port=port,
                    protocol=instance_protocol,
                    check_id=f"service:{service.get('ID', '')}",
                    tags=[str(tag) for tag in service.get("Tags", [])],
                    meta={str(key): str(value) for key, value in meta.items()},
                )
            )

        return instances

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, str] | None = None,
        json: Mapping[str, Any] | None = None,
    ) -> object:
        session = await self._get_session()
        headers: dict[str, str] = {}
        if self._settings.token:
            headers["X-Consul-Token"] = self._settings.token

        async with session.request(
            method,
            f"{self._settings.base_url}{path}",
            headers=headers,
            params=params,
            json=json,
        ) as response:
            if response.status >= 400:
                detail = await response.text()
                raise RegistryError(
                    f"consul request failed: {method} {path} "
                    f"status={response.status}, detail={detail}"
                )
            if response.content_type == "application/json":
                return await response.json()
            return await response.text()

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            timeout = aiohttp.ClientTimeout(total=5)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session
