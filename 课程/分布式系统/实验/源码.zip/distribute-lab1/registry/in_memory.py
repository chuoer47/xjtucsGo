"""In-memory registry used for tests and local smoke runs."""

from __future__ import annotations

import asyncio
import time

from registry.base import BaseServiceRegistry
from shared.models import ProtocolType, ServiceInstance


class InMemoryServiceRegistry(BaseServiceRegistry):
    """Simple in-memory registry with TTL pruning."""

    def __init__(self) -> None:
        self._instances: dict[str, ServiceInstance] = {}
        self._expires_at: dict[str, float] = {}
        self._ttl_seconds: dict[str, int] = {}
        self._lock = asyncio.Lock()

    async def register(
        self,
        instance: ServiceInstance,
        *,
        ttl_seconds: int,
        deregister_after_seconds: int,
    ) -> None:
        del deregister_after_seconds
        async with self._lock:
            self._instances[instance.instance_id] = instance
            self._ttl_seconds[instance.instance_id] = ttl_seconds
            self._expires_at[instance.instance_id] = time.monotonic() + ttl_seconds

    async def heartbeat(self, check_id: str) -> None:
        instance_id = check_id.removeprefix("service:")
        async with self._lock:
            if instance_id in self._expires_at:
                ttl_seconds = self._ttl_seconds[instance_id]
                self._expires_at[instance_id] = time.monotonic() + ttl_seconds

    async def deregister(self, instance_id: str) -> None:
        async with self._lock:
            self._instances.pop(instance_id, None)
            self._expires_at.pop(instance_id, None)
            self._ttl_seconds.pop(instance_id, None)

    async def discover(
        self, service_name: str, protocol: ProtocolType | None = None
    ) -> list[ServiceInstance]:
        async with self._lock:
            self._prune_expired_locked()
            instances = [
                instance
                for instance in self._instances.values()
                if instance.service_name == service_name
                and (protocol is None or instance.protocol == protocol)
            ]
        return sorted(instances, key=lambda item: item.instance_id)

    async def close(self) -> None:
        return None

    def _prune_expired_locked(self) -> None:
        now = time.monotonic()
        expired = [
            instance_id
            for instance_id, expires_at in self._expires_at.items()
            if expires_at <= now
        ]
        for instance_id in expired:
            self._instances.pop(instance_id, None)
            self._expires_at.pop(instance_id, None)
            self._ttl_seconds.pop(instance_id, None)
