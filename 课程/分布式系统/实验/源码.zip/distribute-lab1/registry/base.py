"""Service registry abstractions."""

from __future__ import annotations

import abc

from shared.models import ProtocolType, ServiceInstance


class BaseServiceRegistry(abc.ABC):
    """Common registry interface."""

    @abc.abstractmethod
    async def register(
        self,
        instance: ServiceInstance,
        *,
        ttl_seconds: int,
        deregister_after_seconds: int,
    ) -> None:
        """Register a service instance."""

    @abc.abstractmethod
    async def heartbeat(self, check_id: str) -> None:
        """Refresh a TTL-based health check."""

    @abc.abstractmethod
    async def deregister(self, instance_id: str) -> None:
        """Remove a service instance from the registry."""

    @abc.abstractmethod
    async def discover(
        self, service_name: str, protocol: ProtocolType | None = None
    ) -> list[ServiceInstance]:
        """Discover healthy instances by service name."""

    @abc.abstractmethod
    async def close(self) -> None:
        """Release underlying resources."""
