"""Registry integration package."""
